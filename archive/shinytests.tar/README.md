# shinytests
Shiny app for performing Frequentist and Bayesian tests. 
