# shinytests
Shiny app for performing Frequentist and Bayesian tests. 


# Run application from GitHub

```
shiny::runGitHub("shinytests", "JacintoCC") 
```