egevd.tsoe.init.h <-
function (k, A13, A23, D) 
{
    ((1 - A23^k)/(1 - A13^k)) - D
}
