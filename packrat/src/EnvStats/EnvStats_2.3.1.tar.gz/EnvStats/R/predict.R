predict <-
function (object, ...) 
UseMethod("predict")
